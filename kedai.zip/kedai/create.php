<?php
session_start();
if (!isset($_SESSION['username'])) { header("Location: login.php"); exit(); }

$conn = mysqli_connect("localhost", "root", "", "kedai");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = mysqli_real_escape_string($conn, $_POST['nama_produk']);
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $sql = "INSERT INTO produk (nama_produk, harga, stok) VALUES ('$nama', '$harga', '$stok')";
    
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Product added!'); window.location.href='main.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Add New Product</h2>
        <form method="POST" class="col-md-6">
            <div class="mb-3">
                <label>Product Name</label>
                <input type="text" name="nama_produk" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Price (RM)</label>
                <input type="number" step="0.01" name="harga" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Stock</label>
                <input type="number" name="stok" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Save Product</button>
            <a href="main.php" class="btn btn-secondary">Back</a>
        </form>
    </div>
</body>
</html>
