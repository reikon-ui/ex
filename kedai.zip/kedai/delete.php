<?php
session_start();
if (!isset($_SESSION['username'])) { header("Location: login.php"); exit(); }

$conn = mysqli_connect("localhost", "root", "", "kedai");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM produk WHERE id = $id";
    
    if (mysqli_query($conn, $sql)) {
        header("Location: main.php");
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
}
?>
