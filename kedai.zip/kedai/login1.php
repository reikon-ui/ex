<?php
session_start();

// 1. Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kedai"; // Matches your register1.php database

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// 2. Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // 3. Fetch user from 'pengguna' table
    $sql = "SELECT * FROM pengguna WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        
        // 4. Verify password against hashed password in DB
        if (password_verify($password, $row['password'])) {
            
            // 5. Success! Set Session and redirect
            $_SESSION['username'] = $row['username'];
            header("Location: main.php");
            exit();
            
        } else {
            // Password wrong
            echo "<script>alert('Incorrect password!'); window.history.back();</script>";
            exit();
        }
    } else {
        // Username not found
        echo "<script>alert('User not found!'); window.history.back();</script>";
        exit();
    }

    mysqli_close($conn);
}
?>
