<?php
session_start();
if (!isset($_SESSION['username'])) { header("Location: login.php"); exit(); }

$conn = mysqli_connect("localhost", "root", "", "kedai");
$id = $_GET['id'];

// Fetch current data
$result = mysqli_query($conn, "SELECT * FROM produk WHERE id=$id");
$row = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = mysqli_real_escape_string($conn, $_POST['nama_produk']);
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $sql = "UPDATE produk SET nama_produk='$nama', harga='$harga', stok='$stok' WHERE id=$id";
    
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Updated successfully!'); window.location.href='main.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
   
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Update Product</h2>
        <form method="POST" class="col-md-6">
            <div class="mb-3">
                <label>Product Name</label>
                <input type="text" name="nama_produk" value="<?php echo $row['nama_produk']; ?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Price (RM)</label>
                <input type="number" step="0.01" name="harga" value="<?php echo $row['harga']; ?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Stock</label>
                <input type="number" name="stok" value="<?php echo $row['stok']; ?>" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-warning">Update</button>
            <a href="main.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
