<?php
// 1. Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kedai"; // Change this to your actual database name

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// 2. Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $emel     = mysqli_real_escape_string($conn, $_POST['emel']);

    // 3. Validate passwords match
    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match!'); window.history.back();</script>";
        exit();
    }

    // 4. Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // 5. Insert into 'pengguna' table
    $sql = "INSERT INTO pengguna (username, password, emel) VALUES ('$username', '$hashed_password', '$emel')";

    if (mysqli_query($conn, $sql)) {
        // 6. Redirect to login.php after success
        echo "<script>alert('Registration successful!'); window.location.href='login.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
