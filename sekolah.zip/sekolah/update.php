<?php
session_start();
require_once "config.php";

$id = $_GET['id'];
// Fetch current data
$result = mysqli_query($link, "SELECT * FROM pelajar WHERE id='$id'");
$row = mysqli_fetch_array($result);

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $nama = $_POST["nama"];
    $nomatrik = $_POST["nomatrik"];
    
    $sql = "UPDATE pelajar SET nama=?, nomatrik=? WHERE id=?";
    if($stmt = mysqli_prepare($link, $sql)){
        mysqli_stmt_bind_param($stmt, "sss", $nama, $nomatrik, $id);
        if(mysqli_stmt_execute($stmt)){
            header("location: main.php");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Student</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Update Student: <?php echo $id; ?></h2>
        <form action="" method="post">
            <div class="form-group"><label>Nama</label><input type="text" name="nama" class="form-control" value="<?php echo $row['nama']; ?>"></div>
            <div class="form-group"><label>No Matrik</label><input type="text" name="nomatrik" class="form-control" value="<?php echo $row['nomatrik']; ?>"></div>
            <input type="submit" class="btn btn-primary" value="Update">
            <a href="main.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
