<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>	
<style>
body, html {
  height: 100%;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.hero-image {
  background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("banner.png");
  height: 50%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

.btn-xl {
    padding: 20px 40px;
    font-size: 30px;
    border-radius: 10px;
    width: 300px;
    margin: 20px;
}
</style>
</head>
<body>

<!-- SUCCESS MESSAGE START -->
<?php if(isset($_GET['status']) && $_GET['status'] == 'success'): ?>
    <div class="alert alert-success text-center" style="margin: 0; border-radius: 0;">
        <strong>Success!</strong> Registration successful. You can now login.
    </div>
<?php endif; ?>
<!-- SUCCESS MESSAGE END -->

<div class="hero-image">
  <div class="hero-text">
    <h1 style="font-size:50px">Sistem Maklumat Pelajar</h1>
  </div>
</div>

<div class="container text-center" style="margin-top: 100px;">
    <div class="row">
        <div class="col-md-12">
            <a href="registration.php">
              <button type="button" class="btn btn-warning btn-xl">Register</button>
            </a>
            
            <br><br>
            
            <a href="login.php">
              <button type="button" class="btn btn-primary btn-xl">Login</button>
            </a>
        </div>
    </div>
</div>

</body>
</html>
