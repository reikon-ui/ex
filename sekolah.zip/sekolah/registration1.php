<?php
require_once "config.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = htmlspecialchars(trim($_POST["username"]));
    $nama     = htmlspecialchars(trim($_POST["nama"]));
    $nomatrik = htmlspecialchars(trim($_POST["nomatrik"]));
    $password = password_hash(trim($_POST["password"]), PASSWORD_DEFAULT);

    $sql = "INSERT INTO pelajar (id, pswd, nama, nomatrik) VALUES (?, ?, ?, ?)";
     
    if($stmt = mysqli_prepare($link, $sql)){
        mysqli_stmt_bind_param($stmt, "ssss", $username, $password, $nama, $nomatrik);
        if(mysqli_stmt_execute($stmt)){
            // Redirect with a status message
            header("location: index.php?status=success");
            exit();
        }
        mysqli_stmt_close($stmt);
    }
    mysqli_close($link);
}
?>
