<?php
session_start();
require_once "config.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    $sql = "SELECT id, pswd FROM pelajar WHERE id = ?";
    if($stmt = mysqli_prepare($link, $sql)){
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $id, $hashed_password);
        
        if(mysqli_stmt_fetch($stmt) && password_verify($password, $hashed_password)){
            $_SESSION["loggedin"] = true;
            $_SESSION["id"] = $id;
            header("location: main.php");
            exit();
        }
    }
    $_SESSION["err"] = "Invalid ID or password.";
    header("location: login.php");
    exit();
}
?>
