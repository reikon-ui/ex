<?php
session_start();
if(!isset($_SESSION["loggedin"])) header("location: login.php");

require_once "config.php";

if(isset($_GET["id"])){
    $sql = "DELETE FROM pelajar WHERE id = ?";
    if($stmt = mysqli_prepare($link, $sql)){
        mysqli_stmt_bind_param($stmt, "s", $_GET["id"]);
        if(mysqli_stmt_execute($stmt)){
            header("location: main.php");
            exit();
        }
    }
}
?>
