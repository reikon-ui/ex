<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <title>Register</title>
</head>
<body class="bg-secondary-subtle">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card shadow-sm border-0 p-4">
                    <h3 class="text-primary text-center">Create Account</h3>
                    <hr>
                    <form action="reg_logic.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Username</label>
                            <input type="text" name="username" class="form-control shadow-sm" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Email Address</label>
                            <input type="email" name="email" class="form-control shadow-sm" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Password</label>
                            <input type="password" name="password" class="form-control shadow-sm" required>
                        </div>
                        <button type="submit" name="register" class="btn btn-success w-100 shadow-sm">Sign Up</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
