<?php
session_start();
include 'registration1.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); }

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM users WHERE id=$id");
$user = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    mysqli_query($conn, "UPDATE users SET username='$username', email='$email' WHERE id=$id");
    header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <title>Update User</title>
</head>
<body class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4 card p-4">
            <h3>Update User</h3>
            <form method="POST">
                <input type="text" name="username" class="form-control mb-2" value="<?= $user['username']; ?>" required>
                <input type="email" name="email" class="form-control mb-2" value="<?= $user['email']; ?>" required>
                <button type="submit" name="update" class="btn btn-warning w-100">Update</button>
                <a href="dashboard.php" class="btn btn-link w-100">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>
