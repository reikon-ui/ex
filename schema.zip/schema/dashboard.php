<?php
session_start();
include 'registration1.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); }
$users = mysqli_query($conn, "SELECT * FROM users");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <title>Dashboard</title>
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">Admin Panel</a>
            <a href="logout.php" class="btn btn-light btn-sm">Logout</a>
        </div>
    </nav>
    <div class="container">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h4 class="mb-4">Registered Users</h4>
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th><th>Username</th><th>Email</th><th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($users)): ?>
                        <tr>
                            <td><?= $row['id']; ?></td>
                            <td><?= $row['username']; ?></td>
                            <td><?= $row['email']; ?></td>
                            <td>
                                <a href="update.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
