<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campus Hub - Home</title>
    <link href="https://jsdelivr.net" rel="stylesheet">
</head>
<body class="d-flex flex-column vh-100">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">Campus Hub</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <li class="nav-item"><a class="nav-link" href="registration.php">Register</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5 text-center">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <img src="banner.jpg" class="img-fluid rounded shadow-sm mb-4" style="max-height: 300px; width: 100%; object-fit: cover;">
            <h1 class="display-4 fw-bold">Welcome to Campus Hub</h1>
            <p class="lead text-muted">Your one-stop service for campus management.</p>
            <div class="mt-4">
                <a href="registration.php" class="btn btn-primary btn-lg px-4 me-2">Get Started</a>
                <a href="login.php" class="btn btn-outline-primary btn-lg px-4">Sign In</a>
            </div>
        </div>
    </div>
</div>

<footer class="bg-dark text-white text-center py-3 mt-auto">
    <p class="mb-0">Campus Service Hub &copy; 2026</p>
</footer>

<script src="https://jsdelivr.net"></script>
</body>
</html>
