<?php
session_start();
include 'registration1.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); }

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    mysqli_query($conn, "DELETE FROM users WHERE id=$id");
}
header("Location: dashboard.php");
?>
