<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <title>Login</title>
</head>
<body class="bg-secondary-subtle">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card shadow-sm border-0 p-4">
                    <h3 class="text-center text-primary">Login</h3>
                    <form action="login1.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control shadow-sm" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Password</label>
                            <input type="password" name="password" class="form-control shadow-sm" required>
                        </div>
                        <button type="submit" name="login" class="btn btn-primary w-100 shadow-sm">Login Now</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
